diçonauro = {
     "ingual":"define algo parecido mas nao totalmente igual",
     "menas":"aumentativo de menos, significa mais que menos",
     ""
}