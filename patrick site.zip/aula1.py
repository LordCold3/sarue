
x = 0

for i in range(2,255,2):

    x = x + i

   print(x)

